﻿Memkin Windows 自检修复包 v2

使用方法
1. 保持原来的 Memkin 服务窗口打开。
2. 将整个修复包解压到一个文件夹。
3. 双击 Check-Memkin.cmd，不需要重新安装 Memkin。
4. 成功时显示 All 9 deployment smoke checks passed，并打开人物网页。

修复说明
- 自检的 HTTP/JSON 读取改由已安装的 Node.js 完成，避开不同版本
  PowerShell 对无 charset 的 JSON 响应、中文和日期字符串的解析差异。
- 保留原来 9 项校验，并额外检查已有演示记录的原文和时间戳。
- 只读取已有演示记录并创建新的演示人物/记录，不修改原始记录。
- 失败时显示具体字段差异，并在本修复包目录保存 windows-test-result.json。
- Node.js 没加入系统 PATH 时，自动使用上次安装的私有 Node.js 24。
- 不需要提供 API Key，也不重新安装或清空数据库。

如果网页端口不是 3947，在此文件夹的 PowerShell 运行：
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test-MemkinCRM.ps1 -Port 3948

验证范围
- 云端 Node/PGlite 已运行全部 9 项检查并通过。
- 这是对你截图中自检失败的兼容性修复；是否解决 Windows 上的
  具体失败，要以重跑结果为准。如仍失败，请发送 FAIL 行及其后面的差异。
