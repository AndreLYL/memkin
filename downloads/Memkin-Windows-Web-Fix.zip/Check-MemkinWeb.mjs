import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const args = new Map();
for (let i = 2; i < process.argv.length; i += 2) args.set(process.argv[i], process.argv[i + 1]);
const port = Number(args.get('--port') ?? 3947);
assert.ok(Number.isInteger(port) && port >= 1024 && port <= 65535, 'Invalid port');
const base = `http://127.0.0.1:${port}`;
const report = { ok: false, checked_at: new Date().toISOString(), platform: process.platform, assets: [] };
try {
  console.log(`Waiting for repaired Memkin on ${base} ...`);
  const deadline = Date.now() + 45_000;
  let ready = false;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${base}/api/health`, { signal: AbortSignal.timeout(1_000) });
      if (response.ok && (await response.json()).status === 'ok') { ready = true; break; }
    } catch { /* Wait for startup. */ }
    await delay(1_000);
  }
  assert.ok(ready, 'Server did not become ready. Check its startup window.');
  const response = await fetch(`${base}/people/2`, { signal: AbortSignal.timeout(15_000) });
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type') ?? '', /^text\/html\b/);
  const html = await response.text();
  const scripts = [...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["']/g)].map(match => match[1]);
  const sheets = [...html.matchAll(/<link\b[^>]*\bhref=["']([^"']+\.css(?:\?[^"']*)?)["']/g)].map(match => match[1]);
  assert.ok(scripts.length > 0, 'The page has no JavaScript entry point');
  assert.ok(sheets.length > 0, 'The page has no stylesheet');
  console.log('PASS: Person page serves the application HTML');

  async function checkAsset(path, kind) {
    const url = new URL(path, base);
    assert.equal(url.origin, base, 'Only local packaged assets are checked');
    const asset = await fetch(url, { signal: AbortSignal.timeout(15_000) });
    assert.equal(asset.status, 200, `Asset not found: ${path}`);
    const type = asset.headers.get('content-type') ?? '';
    assert.ok(!type.startsWith('text/html'), `Asset incorrectly returned the SPA HTML: ${path}`);
    if (kind === 'script') assert.match(type, /^(?:text|application)\/(?:javascript|ecmascript)\b/);
    if (kind === 'css') assert.match(type, /^text\/css\b/);
    if (kind === 'font') assert.match(type, /^(?:font\/|application\/font)/);
    const bytes = await asset.arrayBuffer();
    assert.ok(bytes.byteLength > 0, `Asset is empty: ${path}`);
    report.assets.push({ path: url.pathname, type, bytes: bytes.byteLength });
    console.log(`PASS: ${kind} ${url.pathname} (${type})`);
    return new TextDecoder().decode(bytes);
  }
  for (const path of scripts) await checkAsset(path, 'script');
  const fonts = new Set();
  for (const path of sheets) {
    const css = await checkAsset(path, 'css');
    for (const match of css.matchAll(/url\(["']?([^\s)"']+\.woff2?)["']?\)/g)) {
      fonts.add(new URL(match[1], new URL(path, base)).href);
    }
  }
  for (const path of fonts) await checkAsset(path, 'font');
  report.ok = true;
  report.url = `${base}/people?webfix=3`;
  console.log('\nAll Web asset checks passed. The browser can now load the app.');
  console.log(report.url);
} catch (error) {
  report.error = error.message;
  console.error(`FAIL: ${error.stack ?? error.message}`);
  process.exitCode = 1;
} finally {
  if (args.get('--report')) {
    await writeFile(args.get('--report'), `${JSON.stringify(report, null, 2)}\n`, 'utf8');
    console.log(`Report saved to ${args.get('--report')}`);
  }
}
