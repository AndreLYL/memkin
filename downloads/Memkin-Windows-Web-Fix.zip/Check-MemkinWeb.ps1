﻿param([int]$Port = 3947, [string]$ReportPath = '', [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$candidates = @()
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if ($nodeCommand) { $candidates += $nodeCommand.Source }
if ($env:LOCALAPPDATA) {
    $runtimeRoot = Join-Path $env:LOCALAPPDATA 'MemkinCRMTest-195d539\runtime'
    if (Test-Path -LiteralPath $runtimeRoot) {
        foreach ($directory in (Get-ChildItem -LiteralPath $runtimeRoot -Directory -Filter 'node-v24.*-win-*' | Sort-Object Name -Descending)) {
            $candidate = Join-Path $directory.FullName 'node.exe'
            if (Test-Path -LiteralPath $candidate) { $candidates += $candidate }
        }
    }
}
$nodeExe = $null
foreach ($candidate in $candidates) {
    try {
        $major = [int](& $candidate -p "process.versions.node.split('.')[0]")
        if (($LASTEXITCODE -eq 0) -and ($major -ge 22)) { $nodeExe = $candidate; break }
    } catch { }
}
if (-not $nodeExe) { throw 'Cannot find the installed Node.js runtime. Run Install-MemkinTest.cmd first.' }

if (-not $ReportPath) { $ReportPath = Join-Path $PSScriptRoot 'windows-web-test-result.json' }
& $nodeExe (Join-Path $PSScriptRoot 'Check-MemkinWeb.mjs') --port "$Port" --report $ReportPath
if ($LASTEXITCODE -ne 0) { throw "Web checks failed. Send the FAIL line back to the chat. Report: $ReportPath" }
if (-not $NoBrowser) { Start-Process "http://127.0.0.1:$Port/people?webfix=3" }
