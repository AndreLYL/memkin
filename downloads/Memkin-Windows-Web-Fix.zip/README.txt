﻿Memkin Windows 网页白屏修复

1. 在原来的 Memkin 服务窗口按 Ctrl+C，关闭旧服务（不是自检窗口）。
2. 完整解压本 ZIP，双击 Repair-MemkinWeb.cmd。
3. 保持此窗口打开。另一个窗口会检查网页的 JS、CSS 和字体资源，
   全部通过后自动打开 http://127.0.0.1:3947/people?webfix=3。
4. 如果浏览器仍显示旧的白屏，在网页按 Ctrl+F5 强制刷新。

此修复只替换静态文件服务模块，并备份旧模块。
复用现有配置和数据库，不重新安装 npm 包，不清空人物或记录。
如果端口仍被占用，脚本会停止并提示，不会结束其它进程。
如果检测到安装版本不同，脚本会停止，不覆盖该版本。

恢复方式：停止服务后，将安装目录 dist/server 中
serve.js.before-windows-web-fix 复制回 serve.js。
不要再运行旧版 Install-MemkinTest.cmd；它可能重新安装旧包并覆盖修复。
后续启动可继续双击本修复包的 Repair-MemkinWeb.cmd，已有修复会保留。
