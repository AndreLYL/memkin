@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-MemkinWeb.ps1"
if errorlevel 1 pause
