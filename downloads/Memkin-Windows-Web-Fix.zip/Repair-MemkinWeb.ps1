﻿param([int]$Port = 3947)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Run this repair on the Windows PC where Memkin is installed.' }
if ($Port -lt 1024 -or $Port -gt 65535) { throw 'Choose a port between 1024 and 65535.' }
$testRoot = Join-Path $env:LOCALAPPDATA 'MemkinCRMTest-195d539'
$servePath = Join-Path $testRoot 'node_modules\memkin\dist\server\serve.js'
$configPath = Join-Path $testRoot 'memkin-test.yaml'
if (-not (Test-Path -LiteralPath $servePath)) { throw 'Cannot find this Memkin test installation. No files were changed.' }
if (-not (Test-Path -LiteralPath $configPath)) { throw 'Cannot find the existing test configuration. No files were changed.' }

# Refuse to overwrite or kill a running service. Stop it with Ctrl+C first.
$probe = New-Object System.Net.Sockets.TcpClient
$portInUse = $false
try { $probe.Connect('127.0.0.1', $Port); $portInUse = $true } catch { } finally { $probe.Dispose() }
if ($portInUse) { throw "Port $Port is still in use. In the OLD Memkin SERVER window press Ctrl+C, then double-click Repair-MemkinWeb.cmd again." }

$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'patch-info.json') -Raw | ConvertFrom-Json
$fixedPath = Join-Path $PSScriptRoot 'serve.js'
$fixedHash = (Get-FileHash -LiteralPath $fixedPath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($fixedHash -ne $manifest.fixed_sha256) { throw 'Repair file checksum mismatch. Download and extract the repair ZIP again.' }
$installedHash = (Get-FileHash -LiteralPath $servePath -Algorithm SHA256).Hash.ToLowerInvariant()
if (($installedHash -ne $manifest.original_sha256) -and ($installedHash -ne $manifest.fixed_sha256)) {
    throw 'The installed server has a different version. It was not overwritten; send this message back to the chat.'
}
$candidates = @()
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if ($nodeCommand) { $candidates += $nodeCommand.Source }
if ($env:LOCALAPPDATA) {
    $runtimeRoot = Join-Path $env:LOCALAPPDATA 'MemkinCRMTest-195d539\runtime'
    if (Test-Path -LiteralPath $runtimeRoot) {
        foreach ($directory in (Get-ChildItem -LiteralPath $runtimeRoot -Directory -Filter 'node-v24.*-win-*' | Sort-Object Name -Descending)) {
            $candidate = Join-Path $directory.FullName 'node.exe'
            if (Test-Path -LiteralPath $candidate) { $candidates += $candidate }
        }
    }
}
$nodeExe = $null
foreach ($candidate in $candidates) {
    try {
        $major = [int](& $candidate -p "process.versions.node.split('.')[0]")
        if (($LASTEXITCODE -eq 0) -and ($major -ge 22)) { $nodeExe = $candidate; break }
    } catch { }
}
if (-not $nodeExe) { throw 'Cannot find the installed Node.js runtime. Run Install-MemkinTest.cmd first.' }

if ($installedHash -eq $manifest.original_sha256) {
    $backupPath = $servePath + '.before-windows-web-fix'
    if (-not (Test-Path -LiteralPath $backupPath)) { Copy-Item -LiteralPath $servePath -Destination $backupPath }
    Copy-Item -LiteralPath $fixedPath -Destination $servePath -Force
    if ((Get-FileHash -LiteralPath $servePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.fixed_sha256) {
        throw 'The repaired file failed its checksum check. Server was not started.'
    }
    Write-Host 'Windows static-file routing repaired. Original server file backed up.' -ForegroundColor Green
} else { Write-Host 'The Windows Web repair is already installed.' -ForegroundColor Green }

$reportPath = Join-Path $testRoot 'windows-web-test-result.json'
$verifyPath = Join-Path $PSScriptRoot 'Check-MemkinWeb.ps1'
$windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$launchArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-NoExit', '-File', ('"{0}"' -f $verifyPath), '-Port', "$Port", '-ReportPath', ('"{0}"' -f $reportPath))
Start-Process -FilePath $windowsPowerShell -ArgumentList $launchArgs
$cliPath = Join-Path $testRoot 'node_modules\memkin\dist\cli.js'
$webPath = Join-Path $testRoot 'node_modules\memkin\web\dist'
Write-Host 'Keep this window open. The other window checks JS/CSS/fonts and opens the repaired Web UI.' -ForegroundColor Cyan
$serveArgs = @($cliPath, 'serve', '--config', $configPath, '--no-open', '--host', '127.0.0.1', '--port', "$Port", '--web-dist', $webPath)
& $nodeExe @serveArgs
if ($LASTEXITCODE -ne 0) { throw "Memkin exited with code $LASTEXITCODE." }
