import { readFile } from "node:fs/promises";
import { extname, isAbsolute, join, relative, resolve, sep } from "node:path";
// Safe access — referencing a bare `Bun` under Node throws ReferenceError.
const bunRuntime = globalThis.Bun;
export async function serveHttp(opts) {
    if (bunRuntime) {
        const server = bunRuntime.serve({
            port: opts.port,
            hostname: opts.hostname,
            fetch: opts.fetch,
        });
        return { port: server.port, stop: (c) => server.stop(c) };
    }
    // Node fallback via @hono/node-server.
    const { serve } = await import("@hono/node-server");
    return new Promise((resolvePromise) => {
        const server = serve({ fetch: opts.fetch, port: opts.port, hostname: opts.hostname }, (info) => {
            resolvePromise({
                port: info.port,
                stop: (closeActiveConnections) => {
                    const s = server;
                    if (closeActiveConnections)
                        s.closeAllConnections?.();
                    s.close();
                },
            });
        });
    });
}
const MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".map": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
    ".wasm": "application/wasm",
    ".txt": "text/plain; charset=utf-8",
};
/**
 * Serve a static asset from `dir` for the given request pathname, falling back to
 * `index.html` (SPA routing). Runtime-agnostic replacement for `Bun.file`.
 */
export async function serveStaticSpa(dir, pathname) {
    const rel = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
    const root = resolve(dir);
    const target = resolve(root, rel);
    // Use native path semantics: a slash-only prefix rejects every Windows asset.
    // relative() also handles drive roots, while isAbsolute() rejects other drives.
    const fromRoot = relative(root, target);
    if (fromRoot !== ".." && !fromRoot.startsWith(`..${sep}`) && !isAbsolute(fromRoot)) {
        const buf = await readFile(target).catch(() => null);
        if (buf) {
            const type = MIME[extname(target).toLowerCase()] ?? "application/octet-stream";
            return new Response(buf, { headers: { "content-type": type } });
        }
    }
    const index = await readFile(join(dir, "index.html")).catch(() => null);
    if (index)
        return new Response(index, { headers: { "content-type": MIME[".html"] } });
    return new Response("Not found", { status: 404 });
}
//# sourceMappingURL=serve.js.map