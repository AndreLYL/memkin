import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';

const options = new Map();
for (let index = 2; index < process.argv.length; index += 2) {
  options.set(process.argv[index], process.argv[index + 1]);
}
const port = Number(options.get('--port') ?? 3947);
if (!Number.isInteger(port) || port < 1024 || port > 65535) {
  throw new Error('Choose a port between 1024 and 65535.');
}
const base = `http://127.0.0.1:${port}`;
const reportPath = options.get('--report');
const report = {
  ok: false,
  source_commit: '195d5398dece493e0eb65181994f2f44ce5e6ee4',
  test_harness: 'node-utf8-v2',
  checked_at: new Date().toISOString(),
  platform: process.platform,
  node: process.version,
  powershell: options.get('--powershell') ?? null,
  checks_passed: 0,
};
let phase = 'Wait for Memkin';
const text = '小林说他下个月准备搬到杭州，昨天一起聊了工作。';
const captureTime = '2026-10-03T19:07:00+08:00';

async function call(path, method = 'GET', payload) {
  const response = await fetch(`${base}/api/crm${path}`, {
    method,
    headers: payload === undefined ? {} : { 'content-type': 'application/json; charset=utf-8' },
    body: payload === undefined ? undefined : JSON.stringify(payload),
    signal: AbortSignal.timeout(30_000),
  });
  // Keep UTF-8 text and literal timestamp strings out of PowerShell's parser.
  const body = await response.json();
  if (!response.ok) {
    const error = new Error(`HTTP ${response.status}: ${JSON.stringify(body)}`);
    error.status = response.status;
    throw error;
  }
  return body;
}

function passed(label) {
  report.checks_passed += 1;
  console.log(`PASS: ${label}`);
}

try {
  console.log(`Waiting for Memkin on ${base} ...`);
  const deadline = Date.now() + 45_000;
  let ready = false;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${base}/api/health`, { signal: AbortSignal.timeout(1_000) });
      if (response.ok && (await response.json()).status === 'ok') { ready = true; break; }
    } catch { /* The server may still be starting. */ }
    await delay(1_000);
  }
  assert.ok(ready, 'Memkin did not become ready. Check the server window.');

  // Check a previously saved Windows test input, when present, to distinguish
  // a response-decoding problem from a storage problem without changing it.
  const previous = (await call('/records?limit=100')).find(record =>
    record.source === 'voice' && record.external_id?.startsWith('windows-smoke-'));
  if (previous) {
    phase = 'Verify the previously saved test source';
    const saved = await call(`/records/${previous.id}`);
    assert.equal(saved.content, text, 'Previously saved transcript differs');
    assert.equal(saved.captured_at_input, captureTime, 'Previously saved literal timestamp differs');
    report.previous_source_verified = previous.id;
    console.log('INFO: Previously saved test source has the exact original Chinese text and timestamp.');
  }

  phase = 'Create structured person profile';
  const person = await call('/people', 'POST', { profile: {
    name: 'Windows 部署演示', aliases: ['测试朋友'], birthday: { month: 6, day: 12 },
    contacts: [{ kind: 'phone', value: '13800001234', label: '演示号码' }],
  } });
  report.person_id = person.id;
  assert.ok(person.id > 0);
  assert.equal(person.profile.name, 'Windows 部署演示');
  assert.deepEqual(person.profile.aliases, ['测试朋友']);
  passed(phase);

  phase = 'Keep yearless birthday partial';
  assert.equal(person.profile.birthday.year, undefined);
  assert.equal(person.profile.birthday.month, 6);
  passed(phase);

  phase = 'Preserve original transcript and timestamp';
  const record = await call('/records', 'POST', {
    content: text, source: 'voice', captured_at: captureTime, timezone: 'Asia/Shanghai',
    external_id: `windows-smoke-${randomUUID()}`, person_ids: [person.id],
  });
  report.record_id = record.id;
  assert.equal(record.content, text, 'Original Chinese transcript must match exactly');
  assert.equal(record.captured_at_input, captureTime, 'Literal timestamp including +08:00 must match exactly');
  passed(phase);

  phase = 'Manual recording works without a configured model';
  let missingModel = false;
  try { await call(`/records/${record.id}/extract`, 'POST', {}); }
  catch (error) { if (error.status === 503) missingModel = true; else throw error; }
  assert.ok(missingModel, 'Unconfigured model should return HTTP 503');
  passed(phase);

  phase = 'Apply reviewed proposal once, including replay';
  const proposal = await call(`/records/${record.id}/proposals`, 'POST', {
    people: [{ key: 'p', name: 'Windows 部署演示' }],
    entries: [
      { kind: 'interaction', summary: '聊了工作', people: [{ ref: 'p', role: 'participant' }],
        topics: ['工作', '搬家'], time: { value: '2026-10-02', precision: 'day' }, evidence: { quote: '昨天一起聊了工作' } },
      { kind: 'fact', subject: 'p', predicate: '搬家计划', value: '准备搬到杭州', status: 'planned',
        valid_from: { value: '2026-11', precision: 'month' }, evidence: { quote: '下个月准备搬到杭州' } },
    ],
  });
  const identities = { p: { person_id: person.id, expected_revision: person.revision } };
  const applied = await call(`/proposals/${proposal.id}/apply`, 'POST', { identities });
  const replayed = await call(`/proposals/${proposal.id}/apply`, 'POST', { identities });
  assert.equal(applied.entry_ids.length, 2);
  assert.deepEqual(replayed.entry_ids, applied.entry_ids);
  passed(phase);

  phase = 'Keep event time separate from capture time';
  const query = `person_id=${person.id}&from=2026-10-03&to=2026-10-03`;
  const events = await call(`/timeline?${query}&axis=occurred`);
  const captured = await call(`/timeline?${query}&axis=captured`);
  assert.equal(events.length, 0);
  assert.equal(captured.length, 2);
  report.entry_count = captured.length;
  passed(phase);

  phase = 'A planned move does not become a current address';
  const current = await call(`/people/${person.id}`);
  assert.equal(current.profile.addresses.length, 0);
  passed(phase);

  phase = 'Keep correction and previous revision';
  const fact = captured.find(entry => entry.data.kind === 'fact');
  assert.ok(fact, 'The planned fact should be present');
  const corrected = await call(`/entries/${fact.id}`, 'PUT', {
    entry: { ...fact.data, value: '杭州仍是备选，尚未确定' }, expected_revision: fact.revision,
    reason: 'Windows 部署测试：补充计划尚未确定',
  });
  const history = await call(`/history/entry/${fact.id}`);
  assert.equal(corrected.revision, 2);
  assert.equal(history.length, 2);
  report.revision_count = history.length;
  passed(phase);

  phase = 'Correct memory without modifying original source';
  const original = await call(`/records/${record.id}`);
  assert.equal(original.content, text);
  assert.equal(original.captured_at_input, captureTime);
  passed(phase);

  report.ok = true;
  report.url = `${base}/people/${person.id}`;
  console.log('\nAll 9 deployment smoke checks passed.');
  console.log(report.url);
} catch (error) {
  report.failed_check = phase;
  report.error = error.message;
  console.error(`FAIL: ${phase}\n${error.stack ?? error.message}`);
  process.exitCode = 1;
} finally {
  if (reportPath) {
    await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, 'utf8');
    console.log(`Report saved to ${reportPath}`);
  }
}
