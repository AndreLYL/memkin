﻿param([int]$Port = 3947, [switch]$SkipTests)
$ErrorActionPreference = 'Stop'

if ($env:OS -ne 'Windows_NT') { throw 'Run this installer in Windows PowerShell.' }
if ($Port -lt 1024 -or $Port -gt 65535) { throw 'Choose a port between 1024 and 65535.' }

$probe = New-Object System.Net.Sockets.TcpClient
$portInUse = $false
try { $probe.Connect('127.0.0.1', $Port); $portInUse = $true } catch { } finally { $probe.Dispose() }
if ($portInUse) { throw "Port $Port is already in use. Stop the previous test, or run this script with -Port 3948." }

$testRoot = Join-Path $env:LOCALAPPDATA 'MemkinCRMTest-195d539'
New-Item -ItemType Directory -Path $testRoot -Force | Out-Null
$nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
$npmCommand = Get-Command npm.cmd -ErrorAction SilentlyContinue
$nodeMajor = 0
if ($nodeCommand) { $nodeMajor = [int](& $nodeCommand.Source -p "process.versions.node.split('.')[0]") }
if ($nodeCommand -and $npmCommand -and $nodeMajor -ge 22) {
    $nodeExe = $nodeCommand.Source
    $npmExe = $npmCommand.Source
} else {
    Write-Host 'Preparing a private Node.js 24 runtime for this test...' -ForegroundColor Cyan
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $architecture = $env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) { $architecture = $env:PROCESSOR_ARCHITEW6432 }
    if ($architecture -eq 'ARM64') { $nodeArch = 'arm64' }
    elseif ($architecture -eq 'AMD64') { $nodeArch = 'x64' }
    else { throw 'This test bundle requires 64-bit Windows (x64 or ARM64).' }
    $nodeBase = 'https://nodejs.org/dist/latest-v24.x/'
    $sums = (Invoke-WebRequest -Uri ($nodeBase + 'SHASUMS256.txt') -UseBasicParsing -TimeoutSec 60).Content
    $pattern = '(?m)^([a-f0-9]{64})\s+(node-v24\.\d+\.\d+-win-' + $nodeArch + '\.zip)\s*$'
    $nodeMatch = [regex]::Match([string]$sums, $pattern)
    if (-not $nodeMatch.Success) { throw 'Cannot find the official Node.js Windows archive.' }
    $nodeHash = $nodeMatch.Groups[1].Value
    $nodeFile = $nodeMatch.Groups[2].Value
    $toolsRoot = Join-Path $testRoot 'runtime'
    New-Item -ItemType Directory -Path $toolsRoot -Force | Out-Null
    $nodeArchive = Join-Path $toolsRoot $nodeFile
    if (-not (Test-Path -LiteralPath $nodeArchive)) {
        Invoke-WebRequest -Uri ($nodeBase + $nodeFile) -OutFile $nodeArchive -UseBasicParsing -TimeoutSec 300
    }
    if ((Get-FileHash -LiteralPath $nodeArchive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $nodeHash) {
        Remove-Item -LiteralPath $nodeArchive
        throw 'Node.js archive checksum mismatch. Run the installer again to retry the download.'
    }
    $runtimeDir = Join-Path $toolsRoot ([IO.Path]::GetFileNameWithoutExtension($nodeFile))
    $nodeExe = Join-Path $runtimeDir 'node.exe'
    $npmExe = Join-Path $runtimeDir 'npm.cmd'
    if (-not (Test-Path -LiteralPath $npmExe)) { Expand-Archive -LiteralPath $nodeArchive -DestinationPath $toolsRoot -Force }
    $env:Path = $runtimeDir + ';' + $env:Path
}

$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'build-info.json') -Raw | ConvertFrom-Json
$packagePath = Join-Path $PSScriptRoot $manifest.package
$actualHash = (Get-FileHash -LiteralPath $packagePath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualHash -ne $manifest.sha256) { throw 'Package checksum mismatch. Download and extract the test bundle again.' }

Write-Host "Installing Memkin main@195d539 into $testRoot" -ForegroundColor Cyan
& $npmExe install --prefix $testRoot --omit=dev --ignore-scripts --no-audit --no-fund $packagePath
if ($LASTEXITCODE -ne 0) { throw 'npm installation failed. Copy the last error lines back to the chat.' }

$configPath = Join-Path $testRoot 'memkin-test.yaml'
$dataPath = (Join-Path $testRoot 'data').Replace('\', '/') | ConvertTo-Json -Compress
if (-not (Test-Path -LiteralPath $configPath)) {
    $configText = @"
llm:
  provider: mock
  model: mock
store:
  engine: pglite
  data_dir: $dataPath
embedding:
  provider: openai
  model: text-embedding-3-large
  dimensions: 768
  sweep_interval_secs: 0
scheduler:
  enabled: false
sources:
  claude-code:
    enabled: false
  codex:
    enabled: false
  hermes:
    enabled: false
  feishu:
    enabled: false
server:
  host: 127.0.0.1
  http_port: $Port
"@
    [IO.File]::WriteAllText($configPath, $configText, [Text.UTF8Encoding]::new($false))
}

$cliPath = Join-Path $testRoot 'node_modules\memkin\dist\cli.js'
$webPath = Join-Path $testRoot 'node_modules\memkin\web\dist'
if (-not (Test-Path -LiteralPath (Join-Path $webPath 'index.html'))) { throw 'The packaged Web UI is missing.' }
if (-not $SkipTests) {
    $verifyPath = Join-Path $PSScriptRoot 'Test-MemkinCRM.ps1'
    $reportPath = Join-Path $testRoot 'windows-test-result.json'
    $launchArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-NoExit', '-File', ('"{0}"' -f $verifyPath), '-Port', "$Port", '-ReportPath', ('"{0}"' -f $reportPath))
    $windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Start-Process -FilePath $windowsPowerShell -ArgumentList $launchArgs
}

Write-Host ''
Write-Host "Open http://127.0.0.1:$Port/people after MEMKIN_READY appears." -ForegroundColor Green
Write-Host 'Keep this window open. Ctrl+C stops the server; your test data remains on disk.'
Write-Host "Data/config directory: $testRoot"
$serveArgs = @($cliPath, 'serve', '--config', $configPath, '--no-open', '--host', '127.0.0.1', '--port', "$Port", '--web-dist', $webPath)
& $nodeExe @serveArgs
if ($LASTEXITCODE -ne 0) { throw "Memkin exited with code $LASTEXITCODE." }
