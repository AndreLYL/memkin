Memkin Windows CRM test - main@195d539 (PR #139)

使用方式
1. 将整个 ZIP 解压到一个文件夹。
2. 双击 Install-MemkinTest.cmd。
3. 保持启动窗口打开。另一个窗口会自动测试并在成功后打开人物档案网页。

安装过程
- 如果没有可用的 Node.js，会从 nodejs.org 下载 Node.js 24 的便携运行时，
  校验官方 SHA-256；只放在本测试目录中，不改系统 PATH、不需要单独安装 Git/Bun。
- 从随包提供的 tgz 安装已经构建好的 Memkin 和网页，依赖通过 npm 下载。
- 使用 PGlite，本机存储目录为 %LOCALAPPDATA%\MemkinCRMTest-195d539。
- 配置停用自动采集、定时任务和嵌入扫描，先测试手动录入，不需要 AI API Key。
- 自动测试仅创建明确标记的演示人物和演示记录，不读取你的聊天或旧数据库。

打开与退出
- 默认网页：http://127.0.0.1:3947/people
- 关闭服务：在启动窗口按 Ctrl+C。测试数据会保留。
- 再次启动：重新双击同一个 cmd；已有配置和数据不会被覆盖。
- 如果端口被占用，在本文件夹 PowerShell 执行：
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-MemkinTest.ps1 -Port 3948

自检结果
- 自动测试通过后，结果保存在测试目录中的 windows-test-result.json。
- 如失败，保留窗口，把最后的错误文字发到聊天里继续排查。
- 也可手动运行 Test-MemkinCRM.ps1（需要服务已经启动）。

版本与验证
- 此包由 GitHub main 上已合并的 195d539 构建，包含人物 CRM。
- 当前 npm 的同名 0.4.7 发布早于本次 CRM 合并；请使用随包 tgz。
- 已核对包内 CRM/网页资产，安装脚本进行 PowerShell 语法检查。
- 已在云端验证打包后的 Node 服务和 PowerShell 自检；原生 Windows
  的安装结果需要以你本机实际运行的输出为准。
- 此次测试不自动设置开机启动；也不替代真实模型提取质量评估。
