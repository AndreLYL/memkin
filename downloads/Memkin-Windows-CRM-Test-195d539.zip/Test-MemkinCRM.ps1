﻿param([int]$Port = 3947, [string]$ReportPath = '', [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'

# Node handles UTF-8 and JSON; PowerShell only launches the checker.
$candidates = @()
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if ($nodeCommand) { $candidates += $nodeCommand.Source }
if ($env:LOCALAPPDATA) {
    $runtimeRoot = Join-Path $env:LOCALAPPDATA 'MemkinCRMTest-195d539\runtime'
    if (Test-Path -LiteralPath $runtimeRoot) {
        foreach ($directory in (Get-ChildItem -LiteralPath $runtimeRoot -Directory -Filter 'node-v24.*-win-*' | Sort-Object Name -Descending)) {
            $candidate = Join-Path $directory.FullName 'node.exe'
            if (Test-Path -LiteralPath $candidate) { $candidates += $candidate }
        }
    }
}
$nodeExe = $null
foreach ($candidate in $candidates) {
    try {
        $major = [int](& $candidate -p "process.versions.node.split('.')[0]")
        if (($LASTEXITCODE -eq 0) -and ($major -ge 22)) { $nodeExe = $candidate; break }
    } catch { }
}
if (-not $nodeExe) { throw 'Cannot find the installed Node.js runtime. Run Install-MemkinTest.cmd first.' }
if (-not $ReportPath) { $ReportPath = Join-Path $PSScriptRoot 'windows-test-result.json' }
$checkArgs = @((Join-Path $PSScriptRoot 'Test-MemkinCRM.mjs'), '--port', "$Port", '--report', $ReportPath, '--powershell', $PSVersionTable.PSVersion.ToString())
& $nodeExe @checkArgs
if ($LASTEXITCODE -ne 0) { throw "The CRM self-check failed. Copy the FAIL line and its details back to the chat. Report: $ReportPath" }
if (-not $NoBrowser) {
    $report = [IO.File]::ReadAllText($ReportPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    Start-Process $report.url
}
