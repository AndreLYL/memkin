﻿param([int]$Port = 3947, [string]$ReportPath = '', [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$base = "http://127.0.0.1:$Port"

function Call-Crm {
    param([string]$Path, [string]$Method = 'GET', $Payload = $null)
    $request = @{ Uri = "$base/api/crm$Path"; Method = $Method; TimeoutSec = 30; UseBasicParsing = $true }
    if ($null -ne $Payload) {
        $request.ContentType = 'application/json; charset=utf-8'
        $request.Body = [Text.Encoding]::UTF8.GetBytes(($Payload | ConvertTo-Json -Depth 30 -Compress))
    }
    $response = Invoke-RestMethod @request
    if ($response -is [System.Array]) {
        foreach ($item in $response) { $item }
    } else { $response }
}
function Assert-Check {
    param([bool]$Condition, [string]$Label)
    if (-not $Condition) { throw "FAIL: $Label" }
    Write-Host "PASS: $Label" -ForegroundColor Green
}

Write-Host "Waiting for Memkin on $base ..." -ForegroundColor Cyan
$ready = $false
for ($attempt = 0; $attempt -lt 45; $attempt++) {
    try {
        $health = Invoke-RestMethod -Uri "$base/api/health" -TimeoutSec 1 -UseBasicParsing
        if ($health.status -eq 'ok') { $ready = $true; break }
    } catch { }
    Start-Sleep -Seconds 1
}
if (-not $ready) { throw 'Memkin did not become ready. Check the server window and copy its error output.' }

$person = Call-Crm '/people' 'POST' @{ profile = @{
    name = 'Windows 部署演示'; aliases = @('测试朋友'); birthday = @{ month = 6; day = 12 }
    contacts = @(@{ kind = 'phone'; value = '13800001234'; label = '演示号码' })
} }
Assert-Check ($person.id -gt 0) 'Create structured person profile'
Assert-Check (($null -eq $person.profile.birthday.year) -and ($person.profile.birthday.month -eq 6)) 'Keep yearless birthday partial'

$text = '小林说他下个月准备搬到杭州，昨天一起聊了工作。'
$captureTime = '2026-10-03T19:07:00+08:00'
$record = Call-Crm '/records' 'POST' @{
    content = $text; source = 'voice'; captured_at = $captureTime; timezone = 'Asia/Shanghai'
    external_id = ('windows-smoke-' + [Guid]::NewGuid().ToString()); person_ids = @($person.id)
}
Assert-Check (($record.captured_at_input -ceq $captureTime) -and ($record.content -ceq $text)) 'Preserve original transcript and timestamp'
$missingModel = $false
try { $null = Call-Crm "/records/$($record.id)/extract" 'POST' @{} }
catch { if ([int]$_.Exception.Response.StatusCode -eq 503) { $missingModel = $true } else { throw } }
Assert-Check $missingModel 'Manual recording works without a configured model'

$proposal = Call-Crm "/records/$($record.id)/proposals" 'POST' @{
    people = @(@{ key = 'p'; name = 'Windows 部署演示' })
    entries = @(
        @{ kind = 'interaction'; summary = '聊了工作'; people = @(@{ ref = 'p'; role = 'participant' }); topics = @('工作', '搬家'); time = @{ value = '2026-10-02'; precision = 'day' }; evidence = @{ quote = '昨天一起聊了工作' } },
        @{ kind = 'fact'; subject = 'p'; predicate = '搬家计划'; value = '准备搬到杭州'; status = 'planned'; valid_from = @{ value = '2026-11'; precision = 'month' }; evidence = @{ quote = '下个月准备搬到杭州' } }
    )
}
$identities = @{ p = @{ person_id = $person.id; expected_revision = $person.revision } }
$applied = Call-Crm "/proposals/$($proposal.id)/apply" 'POST' @{ identities = $identities }
$replayed = Call-Crm "/proposals/$($proposal.id)/apply" 'POST' @{ identities = $identities }
Assert-Check ((@($applied.entry_ids).Count -eq 2) -and (($applied.entry_ids -join ',') -ceq ($replayed.entry_ids -join ','))) 'Apply reviewed proposal once, including replay'

$events = @(Call-Crm "/timeline?person_id=$($person.id)&axis=occurred&from=2026-10-03&to=2026-10-03")
$captured = @(Call-Crm "/timeline?person_id=$($person.id)&axis=captured&from=2026-10-03&to=2026-10-03")
Assert-Check (($events.Count -eq 0) -and ($captured.Count -eq 2)) 'Keep event time separate from capture time'
$current = Call-Crm "/people/$($person.id)"
Assert-Check (@($current.profile.addresses).Count -eq 0) 'A planned move does not become a current address'

$fact = $captured | Where-Object { $_.data.kind -eq 'fact' } | Select-Object -First 1
$fact.data.value = '杭州仍是备选，尚未确定'
$corrected = Call-Crm "/entries/$($fact.id)" 'PUT' @{ entry = $fact.data; expected_revision = $fact.revision; reason = 'Windows 部署测试：补充计划尚未确定' }
$history = @(Call-Crm "/history/entry/$($fact.id)")
Assert-Check (($corrected.revision -eq 2) -and ($history.Count -eq 2)) 'Keep correction and previous revision'
$original = Call-Crm "/records/$($record.id)"
Assert-Check (($original.content -ceq $text) -and ($original.captured_at_input -ceq $captureTime)) 'Correct memory without modifying original source'

$report = [ordered]@{
    ok = $true; source_commit = '195d5398dece493e0eb65181994f2f44ce5e6ee4'
    checked_at = [DateTimeOffset]::Now.ToString('o'); powershell = $PSVersionTable.PSVersion.ToString()
    person_id = $person.id; record_id = $record.id; entry_count = $captured.Count; revision_count = $history.Count
    url = "$base/people/$($person.id)"
}
if ($ReportPath) {
    [IO.File]::WriteAllText($ReportPath, ($report | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    Write-Host "Report saved to $ReportPath"
}
Write-Host ''
Write-Host 'All deployment smoke checks passed.' -ForegroundColor Green
Write-Host $report.url
if (-not $NoBrowser) { Start-Process $report.url }
